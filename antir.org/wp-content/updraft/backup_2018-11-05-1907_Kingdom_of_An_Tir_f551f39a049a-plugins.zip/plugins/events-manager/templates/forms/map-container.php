<div class="em-location-map-container">
	<div id='em-map-404'  class="em-location-map-404">
		<p><em><?php _e ( 'Location not found', 'events-manager'); ?></em></p>
	</div>
	<div id='em-map' class="em-location-map-content" style='display: none;'></div>
</div>