<?php
function polo_header_before() {
	do_action( 'polo_header_before' );
}

function polo_header_after() {
	do_action( 'polo_header_after' );
}

function polo_content_before() {
	do_action( 'polo_content_before' );
}

function polo_content_after() {
	do_action( 'polo_content_after' );
}

function polo_inner_content_before() {
	do_action( 'polo_inner_content_before' );
}

function polo_inner_content_after() {
	do_action( 'polo_inner_content_after' );
}

function polo_post_before() {
	do_action( 'polo_post_before' );
}

function polo_post_after() {
	do_action( 'polo_post_after' );
}

function polo_page_before() {
	do_action( 'polo_page_before' );
}

function polo_page_after() {
	do_action( 'polo_page_after' );
}

function polo_sidebar_before() {
	do_action( 'polo_sidebar_before' );
}

function polo_sidebar_after() {
	do_action( 'polo_sidebar_after' );
}

function polo_footer_before() {
	do_action( 'polo_footer_before' );
}

function polo_footer_inside() {
	do_action( 'polo_footer_inside' );
}

function polo_footer_after() {
	do_action( 'polo_footer_after' );
}

function polo_loop_before() {
	do_action( 'polo_loop_before' );
}

function polo_loop_after() {
	do_action( 'polo_loop_after' );
}


function polo_woo_product_before() {
	do_action( 'polo_woo_product_before' );
}

function polo_woo_product_after() {
	do_action( 'polo_woo_product_after' );
}

function polo_woo_product_summary() {
	do_action( 'polo_woo_product_summary' );
}

function polo_woo_shop_product_summary() {
	do_action( 'polo_woo_shop_product_summary' );
}

function polo_woo_shop_product_images() {
	do_action( 'polo_woo_shop_product_images' );
}

function polo_woo_product_additional_filter() {
	do_action( 'polo_woo_product_additional_filter' );
}